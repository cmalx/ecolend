import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import DashboardTabs from "@/components/dashboard-tabs"

export default async function DashboardPage() {
  const session = await getSession()

  if (!session) {
    redirect("/auth")
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Welcome, {session.username}</h1>
      <DashboardTabs username={session.username} />
    </div>
  )
}

