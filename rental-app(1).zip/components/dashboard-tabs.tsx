"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { StarIcon } from "lucide-react"
import {
  getMyObjects,
  getRentedObjects,
  getAvailableObjects,
  addObject,
  rentObject,
  returnObject,
  rateObject,
} from "@/lib/rental-actions"
import type { Object } from "@/lib/types"

export default function DashboardTabs({ username }: { username: string }) {
  const [myObjects, setMyObjects] = useState<Object[]>([])
  const [rentedObjects, setRentedObjects] = useState<Object[]>([])
  const [marketplaceObjects, setMarketplaceObjects] = useState<Object[]>([])
  const [rating, setRating] = useState<number>(0)
  const [objectToRate, setObjectToRate] = useState<Object | null>(null)
  const [isRatingDialogOpen, setIsRatingDialogOpen] = useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newObjectName, setNewObjectName] = useState("")

  const loadData = async () => {
    const myObjectsData = await getMyObjects(username)
    const rentedObjectsData = await getRentedObjects(username)
    const marketplaceData = await getAvailableObjects(username)

    setMyObjects(myObjectsData)
    setRentedObjects(rentedObjectsData)
    setMarketplaceObjects(marketplaceData)
  }

  useEffect(() => {
    loadData()
  }, [username])

  const handleAddObject = async () => {
    if (newObjectName.trim()) {
      await addObject(username, newObjectName)
      setNewObjectName("")
      setIsAddDialogOpen(false)
      loadData()
    }
  }

  const handleRentObject = async (objectId: number) => {
    await rentObject(username, objectId)
    loadData()
  }

  const handleReturnObject = async (objectId: number) => {
    const object = rentedObjects.find((obj) => obj.id === objectId)
    if (object) {
      setObjectToRate(object)
      setIsRatingDialogOpen(true)
    }
  }

  const handleSubmitRating = async () => {
    if (objectToRate && rating > 0) {
      await returnObject(username, objectToRate.id)
      await rateObject(objectToRate.id, rating)
      setIsRatingDialogOpen(false)
      setObjectToRate(null)
      setRating(0)
      loadData()
    }
  }

  return (
    <>
      <Tabs defaultValue="my-objects" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="my-objects">My Objects</TabsTrigger>
          <TabsTrigger value="rented">Rented Objects</TabsTrigger>
          <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
        </TabsList>

        <TabsContent value="my-objects">
          <Card>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>My Objects</span>
                <Button onClick={() => setIsAddDialogOpen(true)}>Add Object</Button>
              </CardTitle>
              <CardDescription>Objects you own and can rent out</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {myObjects.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">You don't have any objects yet</p>
                ) : (
                  myObjects.map((object) => (
                    <div key={object.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div>
                        <h3 className="font-medium">{object.name}</h3>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <StarIcon className="h-4 w-4 mr-1 text-yellow-500" />
                          <span>{object.rating.toFixed(1)}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {object.renter === "personne" ? "Available" : `Rented by ${object.renter}`}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rented">
          <Card>
            <CardHeader>
              <CardTitle>Rented Objects</CardTitle>
              <CardDescription>Objects you are currently renting</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {rentedObjects.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">You're not renting any objects</p>
                ) : (
                  rentedObjects.map((object) => (
                    <div key={object.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div>
                        <h3 className="font-medium">{object.name}</h3>
                        <p className="text-sm text-muted-foreground">Owner: {object.owner}</p>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <StarIcon className="h-4 w-4 mr-1 text-yellow-500" />
                          <span>{object.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      <Button variant="outline" onClick={() => handleReturnObject(object.id)}>
                        Return
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="marketplace">
          <Card>
            <CardHeader>
              <CardTitle>Marketplace</CardTitle>
              <CardDescription>Available objects for rent</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {marketplaceObjects.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">No objects available for rent</p>
                ) : (
                  marketplaceObjects.map((object) => (
                    <div key={object.id} className="flex justify-between items-center p-4 border rounded-lg">
                      <div>
                        <h3 className="font-medium">{object.name}</h3>
                        <p className="text-sm text-muted-foreground">Owner: {object.owner}</p>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <StarIcon className="h-4 w-4 mr-1 text-yellow-500" />
                          <span>{object.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      <Button variant="outline" onClick={() => handleRentObject(object.id)}>
                        Rent
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Rating Dialog */}
      <Dialog open={isRatingDialogOpen} onOpenChange={setIsRatingDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rate this object</DialogTitle>
            <DialogDescription>Please rate your experience with {objectToRate?.name}</DialogDescription>
          </DialogHeader>
          <div className="flex justify-center py-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <StarIcon
                key={star}
                className={`h-8 w-8 cursor-pointer ${
                  star <= rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                }`}
                onClick={() => setRating(star)}
              />
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRatingDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmitRating} disabled={rating === 0}>
              Submit Rating
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Object Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Object</DialogTitle>
            <DialogDescription>Enter the details of the object you want to add</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Object Name</Label>
              <Input
                id="name"
                value={newObjectName}
                onChange={(e) => setNewObjectName(e.target.value)}
                placeholder="Enter object name"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddObject} disabled={!newObjectName.trim()}>
              Add Object
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

