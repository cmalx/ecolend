"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { logout } from "@/lib/auth-actions"

export default function Navbar() {
  const pathname = usePathname()
  const router = useRouter()

  // Don't show navbar on auth page
  if (pathname === "/auth") {
    return null
  }

  const handleLogout = async () => {
    await logout()
    router.push("/auth")
    router.refresh()
  }

  return (
    <header className="bg-background border-b">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/dashboard" className="font-bold text-xl">
          Object Rental
        </Link>
        <Button variant="ghost" onClick={handleLogout}>
          Logout
        </Button>
      </div>
    </header>
  )
}

