"use server"

import { createSession, deleteSession } from "./auth"
import { db } from "./db"

export async function login(username: string, password: string) {
  try {
    const user = await db.getUserByCredentials(username, password)

    if (!user) {
      return { success: false, error: "Invalid username or password" }
    }

    await createSession(user.id, user.username)
    return { success: true }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, error: "An error occurred during login" }
  }
}

export async function register(username: string, password: string) {
  try {
    // Check if user already exists
    const existingUser = await db.getUserByUsername(username)

    if (existingUser) {
      return { success: false, error: "Username already exists" }
    }

    // Create new user
    const newUser = await db.createUser(username, password)

    // Create session
    await createSession(newUser.id, newUser.username)

    return { success: true }
  } catch (error) {
    console.error("Registration error:", error)
    return { success: false, error: "An error occurred during registration" }
  }
}

export async function logout() {
  await deleteSession()
  return { success: true }
}

