"use server"

import { cookies } from "next/headers"
import type { Session } from "./types"

// Get the current session from cookies
export async function getSession(): Promise<Session | null> {
  const sessionCookie = cookies().get("session")

  if (!sessionCookie?.value) {
    return null
  }

  try {
    // In a real app, you'd decrypt and verify the session
    const session = JSON.parse(sessionCookie.value)
    return session
  } catch (error) {
    return null
  }
}

// Create a new session
export async function createSession(userId: number, username: string): Promise<void> {
  const session: Session = {
    id: userId,
    username,
  }

  // In a real app, you'd encrypt the session data
  cookies().set("session", JSON.stringify(session), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 1 week
    path: "/",
  })
}

// Delete the session (logout)
export async function deleteSession(): Promise<void> {
  cookies().delete("session")
}

