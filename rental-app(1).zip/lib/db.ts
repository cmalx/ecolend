// This is a simple in-memory database for demonstration purposes
// In a real application, you would use a real database like PostgreSQL, MongoDB, etc.

import type { User, Object } from "./types"

// Initial data
const users: User[] = [
  { id: 1, username: "test", password: "test" },
  { id: 2, username: "Mathieu", password: "matieu1" },
  { id: 3, username: "Floraint26", password: "aimebrico" },
]

const objects: Object[] = [
  { id: 1, owner: "Mathieu", name: "scie sauteuse", rating: 3.6, renter: "Floraint26" },
  { id: 2, owner: "Mathieu", name: "souffleuse", rating: 4.2, renter: "personne" },
  { id: 3, owner: "Mathieu", name: "appareil à raclette", rating: 2.4, renter: "personne" },
  { id: 4, owner: "Floraint26", name: "perceuse", rating: 3.9, renter: "Mathieu" },
  { id: 5, owner: "Floraint26", name: "marteau", rating: 2.8, renter: "personne" },
]

// User-related functions
async function getUserByCredentials(username: string, password: string): Promise<User | null> {
  const user = users.find((u) => u.username === username && u.password === password)
  return user || null
}

async function getUserByUsername(username: string): Promise<User | null> {
  const user = users.find((u) => u.username === username)
  return user || null
}

async function createUser(username: string, password: string): Promise<User> {
  const newUser: User = {
    id: users.length + 1,
    username,
    password,
  }

  users.push(newUser)
  return newUser
}

// Object-related functions
async function getObjectsByOwner(username: string): Promise<Object[]> {
  return objects.filter((obj) => obj.owner === username)
}

async function getObjectsByRenter(username: string): Promise<Object[]> {
  return objects.filter((obj) => obj.renter === username)
}

async function getAvailableObjects(username: string): Promise<Object[]> {
  return objects.filter((obj) => obj.owner !== username && obj.renter === "personne")
}

async function getObjectById(id: number): Promise<Object | null> {
  const object = objects.find((obj) => obj.id === id)
  return object || null
}

async function createObject(owner: string, name: string): Promise<Object> {
  const newObject: Object = {
    id: objects.length + 1,
    owner,
    name,
    rating: 0,
    renter: "personne",
  }

  objects.push(newObject)
  return newObject
}

async function updateObjectRenter(id: number, renter: string): Promise<void> {
  const objectIndex = objects.findIndex((obj) => obj.id === id)

  if (objectIndex !== -1) {
    objects[objectIndex] = {
      ...objects[objectIndex],
      renter,
    }
  }
}

async function updateObjectRating(id: number, rating: number): Promise<void> {
  const objectIndex = objects.findIndex((obj) => obj.id === id)

  if (objectIndex !== -1) {
    objects[objectIndex] = {
      ...objects[objectIndex],
      rating,
    }
  }
}

export const db = {
  getUserByCredentials,
  getUserByUsername,
  createUser,
  getObjectsByOwner,
  getObjectsByRenter,
  getAvailableObjects,
  getObjectById,
  createObject,
  updateObjectRenter,
  updateObjectRating,
}

