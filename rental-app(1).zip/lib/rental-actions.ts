"use server"

import { db } from "./db"
import type { Object } from "./types"

// Get objects owned by the user
export async function getMyObjects(username: string): Promise<Object[]> {
  return db.getObjectsByOwner(username)
}

// Get objects rented by the user
export async function getRentedObjects(username: string): Promise<Object[]> {
  return db.getObjectsByRenter(username)
}

// Get available objects (not owned by the user and not rented)
export async function getAvailableObjects(username: string): Promise<Object[]> {
  return db.getAvailableObjects(username)
}

// Add a new object
export async function addObject(username: string, name: string): Promise<Object> {
  return db.createObject(username, name)
}

// Rent an object
export async function rentObject(username: string, objectId: number): Promise<void> {
  return db.updateObjectRenter(objectId, username)
}

// Return an object
export async function returnObject(username: string, objectId: number): Promise<void> {
  return db.updateObjectRenter(objectId, "personne")
}

// Rate an object
export async function rateObject(objectId: number, rating: number): Promise<void> {
  const object = await db.getObjectById(objectId)

  if (!object) {
    throw new Error("Object not found")
  }

  // Calculate new rating (simple average for this example)
  // In a real app, you'd store individual ratings and calculate the average
  const newRating = (object.rating + rating) / 2

  return db.updateObjectRating(objectId, newRating)
}

