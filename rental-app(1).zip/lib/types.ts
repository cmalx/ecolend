export interface User {
  id: number
  username: string
  password: string
}

export interface Object {
  id: number
  owner: string
  name: string
  rating: number
  renter: string
}

export interface Session {
  id: number
  username: string
}

